package datamodal;
import java.util.ArrayList;
import java.util.List;

import database.StudentMapper;
import org.json.JSONArray;
import org.json.JSONObject;
public  class services {
     public JSONObject jsonObj1=null;
    StudentMapper mapper=new StudentMapper();
    public  static List<Student> list=new ArrayList<>();
    public List<Student> listofdata = mapper.getAllstudents();
    public static int count=0;



    public   void listtojson() {



        JSONArray array=new JSONArray();
        jsonObj1=new JSONObject();

        for(Student b:listofdata){
            array.put(new JSONObject().put("Id", b.id).put("Name", b.name));
        }

        jsonObj1.put("Students", array);

    }

    public JSONObject fetchall() {

         if(count==0){

             Student b1=new Student(101,"nitin");
             Student b2=new Student(102,"shubham");
             Student b3=new Student(103,"omkar");
             list.add(b1);
             list.add(b2);
             list.add(b3);
         }

         count=count+1;

      listtojson();
        return   jsonObj1;

    }
    public void addstudent(int id ,String name){

        Student b4=new Student(id,name);
        list.add(b4);


 }

}