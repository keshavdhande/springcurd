package org.example;
import database.StudentMapper;
import datamodal.Student;
import datamodal.services;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;


@Path("/")
public class application {

    services ob=new services();
    StudentMapper mapper=new StudentMapper();


    @GET
    @Path("/GetallStudents")
        public Response getAll() {
        JSONObject jsonObj1 = ob.fetchall();
        Response response = Response.status(Response.Status.OK).entity(jsonObj1.toString()).build();
        return response;

    }


    @GET
    @Path("/Getbyid/{id}")
    public Response get(@PathParam("id") int id) {

          ob.listtojson();

        for(Student b:ob.listofdata){
            if(b.id==id){
//                System.out.println(b.id + " "+ b.name);
                JSONObject obj1 = new JSONObject();

                String Id= new String(String.valueOf(b.id));
                obj1.put("id:" + Id, "name:" + b.name);

                Response response = Response.status(Response.Status.OK).entity(obj1.toString()).build();
                return response;
            }
        }
        String k="record not found";
        Response respons = Response.status(Response.Status.OK).entity(k).build();
     return respons;

    }

    

    @POST
    @Path("/AddStudent/{id}")
    public Response create(@PathParam("id") int id,String name){

        Student add=new Student(id,name);
        mapper.saveStudent(add);

        ob.addstudent(id,name);
        return Response.status(Response.Status.CREATED).build();


    }



    @PUT
    @Path("/UpdateStudent/{id}")
    public String Update(@PathParam("id") int id,String name){

        Student Update=new Student(id,name);

        mapper.updateStudent(Update);


        return "student updated sucessfully";
    }



    @DELETE
    @Path("/DeleteStudentbyId/{id}")
    public String Delete(@PathParam("id") int id,String name){

        Student Delete=new Student(id,name);

        mapper.deletestudent(Delete);

        return  "record  deleted sucessfully";
    }




}