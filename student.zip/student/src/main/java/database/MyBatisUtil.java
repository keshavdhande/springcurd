package database;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;

public class MyBatisUtil {
    private static SqlSessionFactory factory;
    private static final long serialVersionUID = 1L;
    private MyBatisUtil() {
    }
    static {
        //mybatis-config.xml path
        String resource = "/home/techbulls/Desktop/Project/student/src/main/resources/mybatis-config.xml";
        URL o = Thread.currentThread().getContextClassLoader().getResource(resource);
        //String path = o.getPath().replace("classes", "config");
        InputStream is=null;
        try {
            is = new FileInputStream(new File(resource));
            factory = new SqlSessionFactoryBuilder().build(is);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Create sqlSession object
     *
     * @return
     */
    public static SqlSession getSqlSessionFactory()
    {
        return factory.openSession();
    }

    /**
     * Close the sqlSession session
     *
     * @param sqlSession
     */
   /* public static void closeSqlSession(SqlSession sqlSession) {
        try {
            if (null != sqlSession) {
                sqlSession.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

}
