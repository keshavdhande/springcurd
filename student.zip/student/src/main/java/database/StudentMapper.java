package database;
import java.util.ArrayList;
import java.util.List;

import datamodal.Student;
import org.apache.ibatis.session.SqlSession;


public class StudentMapper {

    public  static List<Student> studentsList=new ArrayList<>();

    public List<Student> getAllstudents(){
        SqlSession session = MyBatisUtil.getSqlSessionFactory();

    studentsList = session.selectList("getAllstudents");
        session.commit();
        session.close();
        return studentsList;
    }

    public void saveStudent(Student student){
        SqlSession session = MyBatisUtil.getSqlSessionFactory();
        session.insert("insertstudent", student);
        session.commit();
        session.close();
    }


    public void updateStudent(Student student){

        SqlSession session = MyBatisUtil.getSqlSessionFactory();
        session.insert("updateStudent", student);
        session.commit();
        session.close();
    }

public void deletestudent(Student student){

    SqlSession session = MyBatisUtil.getSqlSessionFactory();
    session.insert("deletestudent", student);
    session.commit();
    session.close();


}

}





